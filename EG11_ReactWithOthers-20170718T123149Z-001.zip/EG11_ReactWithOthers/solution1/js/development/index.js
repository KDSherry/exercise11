import React from 'react';
import ReactDOM from 'react-dom';

import FilterableProductTable from './components/FilterableProductTable';

ReactDOM.render(
  <FilterableProductTable />, document.querySelector("#app")
);
