import React from 'react';

export default class ProductTable extends React.Component {
  render() {
    return (
        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
    );
  }
}
